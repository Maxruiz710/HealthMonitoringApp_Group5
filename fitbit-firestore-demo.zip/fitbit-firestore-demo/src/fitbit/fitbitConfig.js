const ClientID = '23RSQD';
const ClientSecret = '64f594edde8f117d6f02fe99f874b67f';
const RedirectUri = 'https://healthmonitoringapp-960e5.web.app/'; // the redirectURL in FitBit app

export {ClientID, ClientSecret, RedirectUri};
