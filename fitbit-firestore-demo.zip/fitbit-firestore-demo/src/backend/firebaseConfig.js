/*
Get this from Firebase app settings
*/

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC4u-beuO5MF0VOEtj5KmCh01dNv0Bw7Sc",
  authDomain: "healthmonitoringapp-960e5.firebaseapp.com",
  projectId: "healthmonitoringapp-960e5",
  storageBucket: "healthmonitoringapp-960e5.appspot.com",
  messagingSenderId: "1014063346999",
  appId: "1:1014063346999:web:6a0ffa4a566524b80756b2"
};

export default firebaseConfig;